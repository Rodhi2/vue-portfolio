
const projects = [
	{
		id: 1,
		title: 'SDF Cambodia',
		category: 'Web Application',
		
	},
	{
		id: 2,
		title: 'SAHAKA',
		category: 'Web Application',
		
	},
	{
		id: 3,
		title: 'APD Website',
		category: 'API',
		
	},
	{
		id: 4,
		title: 'Staff Management',
		category: 'Microservice',
	
	{
		id: 5,
		title: 'SportDate',
		category: 'Mobile Application',
	
	},
	{
		id: 6,
		title: 'POS Camcyber',
		category: 'Web Application',
		
	},
];

export default projects;
